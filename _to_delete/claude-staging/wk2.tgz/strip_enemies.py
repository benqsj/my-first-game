import re,sys
p=sys.argv[1]; s=open(p).read()
blocks=re.split(r'(?=^\[)', s, flags=re.M)
out=[]; removed=[]
for b in blocks:
    m=re.match(r'\[node name="(Imp[123]|Puglin[123])" parent="Enemies"', b)
    if m: removed.append(m.group(1)); continue
    out.append(b)
open(p,'w').write(''.join(out)); print('removed',removed)
